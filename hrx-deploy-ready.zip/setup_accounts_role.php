<?php

use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use App\Models\User;

require __DIR__ . '/vendor/autoload.php';
$app = require_once __DIR__ . '/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

echo "--- Setting up Accounts Role ---\n";

// Create or get the 'accounts' role
$accountsRole = Role::firstOrCreate(['name' => 'accounts', 'guard_name' => 'web']);

// Define the permissions needed based on user request:
$permissions = [
    'hr.leaves.view', 'hr.leaves.approve', 'leaveRequests.view', 'leaveRequests.approve', // View and mark leaves approved
    'payroll.manage', // Update salary breakdown, generate payroll, display to users
    'hr.attendance.view', 'hr.attendance.manage', 'Manage Attendance', // Check and import attendance
    'hr.employees.view', 'hr.employees.edit', // Update employee salary details
    'hr.approvals.view', 'approvals.view', 'hr.dashboard.view', // General access to HR modules
];

// Ensure permissions exist and gather them
$permsToSync = [];
foreach ($permissions as $permName) {
    $permsToSync[] = Permission::firstOrCreate(['name' => $permName, 'guard_name' => 'web']);
}

// Sync permissions to the accounts role
$accountsRole->syncPermissions($permsToSync);

// Find the accounts department and assign the role to those users
$accountsDept = \App\Models\Department::where('name', 'Accounts')->first();
if ($accountsDept) {
    $designations = \App\Models\Designation::where('department_id', $accountsDept->id)->pluck('id');
    $users = User::whereIn('designation_id', $designations)->get();
    foreach ($users as $user) {
        $user->assignRole($accountsRole);
        echo "Assigned accounts role to: {$user->email}\n";
    }
} else {
    echo "Accounts department not found.\n";
}

// Clear Cache
app()[\Spatie\Permission\PermissionRegistrar::class]->forgetCachedPermissions();
echo "Permission cache cleared.\n";

echo "Accounts role setup complete.\n";
