<?php

return [
    'name' => 'AiChat',
];
