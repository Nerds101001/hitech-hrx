$(function(){$("#useDefaultPassword").on("change",function(){$(this).is(":checked")?$("#passwordDiv").hide():$("#passwordDiv").show()})});
