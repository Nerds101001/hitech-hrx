$(function(){$.ajaxSetup({headers:{"X-CSRF-TOKEN":$('meta[name="csrf-token"]').attr("content")}}),getBackupList()});window.getBackupList=function(){$("#backupListDiv").html('<div class="d-flex justify-content-center mt-5"><div class="spinner-border" role="status"><span class="visually-hidden">Loading...</span></div></div>'),$.ajax({url:`${baseUrl}utilities/getBackupList`,type:"GET",success:function(e){console.log(e);const a=$("#backupListDiv");if(e&&e.status==="success"){const t=e.data;var s="";t&&t.length>0?t.forEach(n=>{s+=` <div class="col-12 col-md-6 col-lg-4 mt-3">
          <div class="card h-100 shadow-sm">
            <div class="card-body">
              <h5 class="card-title"><i class="bx bx-archive"></i> ${n.file_name}</h5>
              <p class="card-text"><i class="bx bx-hdd"></i>  ${n.file_size}</p>
              <p class="card-text"><i class="bx bx-time-five"></i> ${n.last_modified}</p>
              <div class="d-flex justify-content-between">
                <a href="${baseUrl}utilities/downloadBackup/${n.file_name}" class="btn btn-primary flex-grow-1 me-2">Download</a>
                <button type="button" class="btn btn-success btn-icon me-2" title="Restore Backup" onclick="confirmRestore('${n.file_name}')">
                  <i class="bx bx-reset"></i>
                </button>
                <button type="button" class="btn btn-danger btn-icon" title="Delete Backup" onclick="confirmDelete('${n.file_name}')">
                  <i class="bx bx-trash"></i>
                </button>
              </div>
            </div>
          </div>
        </div>`}):s=`<div class="card-body text-center">
    <div class="alert alert-light" role="alert">
      <i class="bx bx-folder-open text-muted" style="font-size: 3rem;"></i>
      <h5 class="mt-3 text-danger">No backups found.</h5>
      <p class="text-muted">It looks like you haven't created any backups yet. Click the button below to create your first backup.</p>
      <a href="" onclick="createBackup()" class="btn btn-primary mt-3">
        <i class="bx bx-cloud-upload me-2"></i> Create First Backup
      </a>
    </div>
  </div>`,a.html(s)}else a.html('<div class="alert alert-danger">There was an issue fetching the backup list. Please try again.</div>')},error:function(e){console.log(e)}})};window.confirmDelete=function(e){var a=$('meta[name="csrf-token"]').attr("content");Swal.fire({title:"Are you sure?",text:"You won't be able to revert this!",icon:"warning",confirmButtonText:"Yes, delete it!",customClass:{confirmButton:"btn btn-primary me-3",cancelButton:"btn btn-label-secondary"}}).then(s=>{if(s.isConfirmed){var t=document.createElement("form");t.method="POST",t.action=`${baseUrl}utilities/deleteBackup/${e}`;var n=document.createElement("input");n.type="hidden",n.name="_token",n.value=a,t.appendChild(n);var i=document.createElement("input");i.type="hidden",i.name="_method",i.value="DELETE",t.appendChild(i),document.body.appendChild(t),t.submit()}})};window.createBackup=function(){var e=$('meta[name="csrf-token"]').attr("content");Swal.fire({title:"Creating Backup...",text:"Please wait while your backup is being created.",icon:"info",allowOutsideClick:!1,allowEscapeKey:!1,showConfirmButton:!1,showCancelButton:!1,showDenyButton:!1,customClass:{},willOpen:()=>{Swal.showLoading()}}),$.ajax({url:`${baseUrl}utilities/createBackup`,type:"POST",data:{_token:e},success:function(a){Swal.fire({title:"Success!",text:"Backup has been created successfully.",customClass:{confirmButton:"btn btn-success"}}).then(()=>{location.reload()})},error:function(a){Swal.fire({title:"Error!",text:"There was an issue creating the backup. Please try again.",icon:"error",confirmButtonText:"OK"})}})};window.confirmRestore=function(e){Swal.fire({title:"Are you sure?",text:"This will restore the "+e+" file.",icon:"warning",customClass:{confirmButton:"btn btn-primary me-3",cancelButton:"btn btn-label-secondary"},confirmButtonText:"Yes, restore it!",showCancelButton:!0,cancelButtonText:"Cancel"}).then(a=>{a.isConfirmed&&(showRestoringLoader(),$.ajax({url:`${baseUrl}utilities/restoreBackup/${e}`,type:"POST",success:function(s){console.log(s);let t=0,n=setInterval(()=>{t+=20,updateRestoreProgress(t,`Restoring ${e}...`),t>=100&&(clearInterval(n),Swal.fire({title:"Success!",text:"Backup has been restored successfully.",icon:"success",confirmButtonText:"OK",customClass:{confirmButton:"btn btn-success"}}))},1e3)},error:function(s){console.log(s),Swal.fire({title:"Error!",text:"There was an issue restoring the backup. Please try again.",icon:"error",customClass:{confirmButton:"btn btn-danger"},confirmButtonText:"OK"})}}))})};window.showRestoringLoader=function(e="Initializing..."){Swal.fire({title:"Restoring Backup...",html:`
      <p>Please wait while your backup is being restored.</p>
      <p class="text-warning">Warning: This action will overwrite existing data.</p>
      <p class="text-warning">Do not close this window or navigate away during the restore process.</p>
      <div class="progress mt-3" style="height: 25px;">
        <div id="progress-bar" class="progress-bar" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">0%</div>
      </div>
      <p id="current-process" class="mt-3">${e}</p>
    `,icon:"info",allowOutsideClick:!1,allowEscapeKey:!1,showConfirmButton:!1,showCancelButton:!1,showDenyButton:!1,customClass:{},willOpen:()=>{Swal.showLoading()}})};window.updateRestoreProgress=function(e,a){const s=document.getElementById("progress-bar"),t=document.getElementById("current-process");s.style.width=e+"%",s.setAttribute("aria-valuenow",e),s.innerText=e+"%",t.innerText=a};
