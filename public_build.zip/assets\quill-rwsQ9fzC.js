import{Q as i}from"./quill-X0IdxGHq.js";import"./_commonjsHelpers-BosuxZz1.js";try{window.Quill=i}catch{}
