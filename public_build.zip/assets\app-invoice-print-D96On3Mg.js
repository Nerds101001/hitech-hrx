(function(){window.print()})();
