import{C as i,i as n,c as d,b as a,a as w}from"./index-DvPLVQji.js";try{window.Calendar=i,window.dayGridPlugin=n,window.interactionPlugin=d,window.listPlugin=a,window.timegridPlugin=w}catch{}
